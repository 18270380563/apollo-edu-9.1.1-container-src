class SECONDFPN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  deblocks : __torch__.torch.nn.modules.container.___torch_mangle_59.ModuleList
