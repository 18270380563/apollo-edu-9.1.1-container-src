class ConvTranspose2d(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.mmcv.cnn.bricks.wrappers.___torch_mangle_51.ConvTranspose2d,
    argument_1: Tensor) -> Tensor:
    weight = self.weight
    input = torch._convolution(argument_1, weight, None, [2, 2], [0, 0], [1, 1], True, [0, 0], 1, False, False, True, True)
    return input
